This data is extracted from last year's winning bot, running on multiple maps.

First three columns are the actions the bot made, given rest of the columns, the sensors.

Actions: Acceleration, Brake, Steering
Sensors: Speed, Track Position, Angle to Track Axis, 18x Track Edge Sensors

Note that you are not obliged to use this data, as this is only given as a fast way to start. You can collect your own data, or train your network any other way.

You can find the run these data are extracted from here, so you can have an idea to what the data represents:
https://www.youtube.com/watch?v=pX-UDQdtmBM
